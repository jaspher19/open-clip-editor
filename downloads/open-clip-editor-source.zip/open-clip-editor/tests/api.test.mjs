import test from 'node:test';import assert from 'node:assert/strict';import path from 'node:path';import fs from 'node:fs';import {randomUUID} from 'node:crypto';
import {createApp,linkOldPosts} from '../server/app.mjs';import {JobStore} from '../server/jobs.mjs';import {ROOT} from '../server/config.mjs';
import {YouTubeClient} from '../server/youtube.mjs';
test('API rejects non-YouTube URLs, exposes persisted jobs, blocks foreign mutation origins',async t=>{
 const store=new JobStore(path.join(ROOT,'.cache','api-tests-'+randomUUID()));const pending=new Set();const queue={isBusy:id=>pending.has(id),enqueue(id){pending.add(id);},cancel(id){pending.delete(id);}};
 const app=createApp({store,queue,youtube:new YouTubeClient({folder:path.join(store.root,'youtube-auth')})});const server=await new Promise(r=>{const s=app.listen(0,'127.0.0.1',()=>r(s));});t.after(()=>new Promise(r=>server.close(r)));const base=`http://127.0.0.1:${server.address().port}`;
 let r=await fetch(base+'/api/jobs',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({url:'http://127.0.0.1/secrets'})});assert.equal(r.status,400);
 r=await fetch(base+'/api/jobs',{method:'POST',headers:{'content-type':'application/json',origin:'https://evil.test'},body:'{}'});assert.equal(r.status,403);
 r=await fetch(base+'/api/jobs',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({url:'https://youtu.be/R6gKMvetXUU'})});assert.equal(r.status,202);const job=await r.json();assert.ok(job.id);assert.equal(job.options.picker,'heuristic');assert.equal(job.source.path,undefined);
 r=await fetch(base+'/api/jobs/'+job.id);assert.equal(r.status,200);assert.equal((await r.json()).id,job.id);
 r=await fetch(base+'/api/jobs/'+job.id+'/retry',{method:'POST'});assert.equal(r.status,409);
 r=await fetch(base+'/api/jobs/no-such-job');assert.equal(r.status,400);
 r=await fetch(base+'/api/jobs');assert.equal((await r.json()).length,1);
 pending.delete(job.id);const clipId=randomUUID();store.update(job.id,{status:'complete',metadata:{duration:100},clips:[{id:clipId,start:0,end:30,title:'Test',settings:{},dirty:false,kept:true}],exports:[{clipId,filename:clipId+'.mp4'}]});
 fs.writeFileSync(path.join(store.folder(job.id),'transcript.json'),JSON.stringify({words:Array.from({length:40},(_,i)=>({start:i,end:i+.5,text:'word'}))}));
 r=await fetch(base+`/api/jobs/${job.id}/clips/${clipId}`,{method:'PATCH',headers:{'content-type':'application/json'},body:JSON.stringify({kept:false})});assert.equal(r.status,200);assert.equal((await r.json()).dirty,false);
 store.update(job.id,{clips:[{id:clipId,title:'Test',dirty:true,kept:true}]});
 const exports=path.join(store.folder(job.id),'exports');fs.mkdirSync(exports);fs.writeFileSync(path.join(exports,clipId+'.mp4'),'old media');
 r=await fetch(base+`/api/jobs/${job.id}/export/${clipId}?download=1`);assert.equal(r.status,409);
 pending.delete(job.id);store.update(job.id,{clips:[{id:clipId,settings:{hookText:'Keep this hook',musicEnabled:true},dirty:false,kept:true}]});
 r=await fetch(base+`/api/jobs/${job.id}/templates`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({templateId:'word-punch',clipIds:[clipId]})});assert.equal(r.status,200);const themed=(await r.json()).clips[0];assert.equal(themed.settings.font,'anton');assert.equal(themed.settings.hookText,'Keep this hook');assert.equal(themed.settings.musicEnabled,true);assert.equal(themed.dirty,true);
 r=await fetch(base+'/api/automations',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({url:'https://youtu.be/R6gKMvetXUU',posting:'private',publishingEnabled:true})});assert.equal(r.status,201);const script=await r.json();assert.equal(script.enabled,false);
 r=await fetch(base+`/api/automations/${script.id}/start`,{method:'POST',headers:{'content-type':'application/json'},body:'{}'});assert.equal(r.status,400);assert.match((await r.json()).error,/Connect a YouTube channel/);
 r=await fetch(base+'/api/youtube/status');const connection=await r.json();assert.equal(connection.connected,false);assert.equal(connection.client_secret,undefined);
 r=await fetch(base+`/api/automations/${script.id}/script`);assert.equal(r.status,200);assert.equal((await r.json()).posting,'private');
 store.update(job.id,{status:'complete',metadata:{duration:100},clips:[{id:clipId,start:0,end:30,title:'Test moment',settings:{},kept:true,score:80}]});pending.delete(job.id);
 r=await fetch(base+`/api/jobs/${job.id}/clips/${clipId}`,{method:'PATCH',headers:{'content-type':'application/json'},body:JSON.stringify({metadata:{title:'My upload title',description:'My reviewed description',tags:['reviewed']},settings:{contextText:'The audience needs this context',titleMode:'persistent'}})});assert.equal(r.status,200);assert.equal((await r.json()).metadata.generatedBy,'owner edited');
 r=await fetch(base+`/api/jobs/${job.id}/context`,{method:'POST',headers:{'content-type':'application/json'},body:'{}'});assert.equal(r.status,200);assert.equal((await r.json()).clips[0].metadata.description,'My reviewed description');
 store.update(job.id,{compilation:{filename:'old.mp4'}});r=await fetch(base+`/api/jobs/${job.id}/clips/${clipId}`,{method:'PATCH',headers:{'content-type':'application/json'},body:JSON.stringify({title:'New clip title'})});assert.equal(r.status,200);assert.equal(store.get(job.id).compilation,null);r=await fetch(base+`/api/jobs/${job.id}/compilation`);assert.equal(r.status,404);
 app.locals.automation.active.set('fixture',{jobId:job.id});r=await fetch(base+`/api/jobs/${job.id}/clips/${clipId}`,{method:'PATCH',headers:{'content-type':'application/json'},body:JSON.stringify({title:'Changed during upload'})});assert.equal(r.status,409);assert.equal(store.get(job.id).clips[0].title,'New clip title');app.locals.automation.active.delete('fixture');
 r=await fetch(base+`/api/jobs/${job.id}/download?clips=${clipId}`);assert.equal(r.status,409);
 r=await fetch(base+'/api/health');const health=await r.json();assert.ok(['clean','creator','focus','impact','podcast','explain','story','gaming'].every(s=>health.styles.includes(s)));assert.equal(health.templates.length,18);assert.equal(health.fonts.length,7);
 const form=new FormData();form.append('music',new Blob(['not audio']),'bad.exe');r=await fetch(base+`/api/jobs/${job.id}/music`,{method:'POST',body:form});assert.equal(r.status,400);
 store.update(job.id,{clips:[{id:clipId,title:'Test',settings:{},dirty:false,kept:true}]});
 r=await fetch(base+`/api/jobs/${job.id}/export`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({clipIds:[clipId],settings:{musicEnabled:true}})});assert.equal(r.status,202);assert.equal(store.get(job.id).clips[0].dirty,true);
 r=await fetch(base+`/api/jobs/${job.id}/export/${clipId}?download=1`);assert.equal(r.status,409);
});
test('a clip\'s Post panel is pre-filled with generated YouTube metadata and its export format',async t=>{
 const store=new JobStore(path.join(ROOT,'.cache','api-tests-'+randomUUID()));const queue={isBusy:()=>false,enqueue(){},cancel(){}};
 const app=createApp({store,queue,youtube:new YouTubeClient({folder:path.join(store.root,'youtube-auth')})});const server=await new Promise(r=>{const s=app.listen(0,'127.0.0.1',()=>r(s));});t.after(()=>{server.close();fs.rmSync(store.root,{recursive:true,force:true});});const base=`http://127.0.0.1:${server.address().port}`;
 const job=store.create({type:'local',path:'x.mp4',name:'Costume night'},{});store.update(job.id,{status:'complete',title:'Costume night',clips:[{id:'c1',start:0,end:30,title:'The costume reveal nobody expected',hook:'',score:80,reasons:[],kept:true,settings:{},contextText:'A costume reveal at a party'}],exports:[]});
 let r=await fetch(`${base}/api/jobs/${job.id}/clips/c1/publication`);assert.equal(r.status,200);const p=await r.json();
 assert.equal(p.metadata.title,'The costume reveal nobody expected');assert.ok(Array.isArray(p.metadata.tags));assert.ok(p.metadata.categoryId);assert.equal(p.exported,false);assert.equal(p.connected,false);
 r=await fetch(`${base}/api/jobs/${job.id}/clips/missing/publication`);assert.equal(r.status,404);});
test('stream summary requests validate format, length and a finished transcript before queueing',async t=>{
 const store=new JobStore(path.join(ROOT,'.cache','api-tests-'+randomUUID()));const queued=[];const queue={isBusy:()=>false,enqueue:(...a)=>queued.push(a),cancel(){}};
 const app=createApp({store,queue,youtube:new YouTubeClient({folder:path.join(store.root,'youtube-auth')})});const server=await new Promise(r=>{const s=app.listen(0,'127.0.0.1',()=>r(s));});t.after(()=>{server.close();fs.rmSync(store.root,{recursive:true,force:true});});const base=`http://127.0.0.1:${server.address().port}`;
 const job=store.create({type:'local',path:'x.mp4',name:'Stream'},{});store.update(job.id,{status:'complete'});const post=body=>fetch(`${base}/api/jobs/${job.id}/summary`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});
 assert.equal((await post({format:'tiktok'})).status,400);assert.equal((await post({format:'video',targetSeconds:123})).status,400);
 let r=await post({format:'video',targetSeconds:600});assert.equal(r.status,400);assert.match((await r.json()).error,/transcribed/);
 fs.writeFileSync(path.join(store.folder(job.id),'transcript.json'),'{"words":[],"duration":0}');r=await post({format:'shorts',targetSeconds:60});assert.equal(r.status,202);assert.deepEqual(queued.at(-1),[job.id,'summary',[],{format:'shorts',targetSeconds:60}]);
 assert.equal((await fetch(`${base}/api/jobs/${job.id}/summary`)).status,404);assert.equal((await fetch(`${base}/api/jobs/${job.id}/clips/stream-summary/publication`)).status,404);});
test('Write with AI sends the clip\'s edited transcript and returns limit-checked YouTube metadata',async t=>{
 const store=new JobStore(path.join(ROOT,'.cache','api-tests-'+randomUUID()));const queue={isBusy:()=>false,enqueue(){},cancel(){}};const seen=[];
 const writeMetadata=async input=>{seen.push(input);return {title:'Spider-Man gets caught off guard',description:'Hook\nMore',tags:['spider-man','irl'],hashtags:['#spiderman'],rationale:'Surprise lead.',model:'claude-opus-5-5'};};
 const app=createApp({store,queue,writeMetadata,youtube:new YouTubeClient({folder:path.join(store.root,'youtube-auth')})});const server=await new Promise(r=>{const s=app.listen(0,'127.0.0.1',()=>r(s));});t.after(()=>{server.close();fs.rmSync(store.root,{recursive:true,force:true});});const base=`http://127.0.0.1:${server.address().port}`;
 const job=store.create({type:'youtube',url:'https://youtu.be/R6gKMvetXUU'},{});store.update(job.id,{status:'complete',title:'Halloween stream',clips:[{id:'c1',start:1,end:3,title:'t',hook:'',score:70,reasons:[],kept:true,settings:{outputFormat:'video'},wordEdits:{1:'Spider-Man'}}],exports:[]});
 fs.writeFileSync(path.join(store.folder(job.id),'transcript.json'),JSON.stringify({duration:5,words:[{start:0,end:.5,text:'before'},{start:1,end:1.5,text:'spider man'},{start:2,end:2.5,text:'appears!'},{start:4,end:4.5,text:'after'}]}));
 let r=await fetch(`${base}/api/jobs/${job.id}/clips/c1/metadata/ai`,{method:'POST',headers:{'content-type':'application/json'},body:'{}'});assert.equal(r.status,200);const body=await r.json();
 assert.equal(seen[0].transcript,'Spider-Man appears!','only the clip\'s words, with caption corrections');assert.equal(seen[0].format,'video');assert.equal(seen[0].sourceUrl,'https://youtu.be/R6gKMvetXUU');assert.deepEqual(seen[0].trending,[],'not connected: no trending lookup');
 assert.equal(body.metadata.title,'Spider-Man gets caught off guard');assert.deepEqual(body.hashtags,['#spiderman']);assert.equal(body.trendingUsed,0);
 r=await fetch(`${base}/api/jobs/${job.id}/clips/stream-summary/metadata/ai`,{method:'POST',headers:{'content-type':'application/json'},body:'{}'});assert.equal(r.status,404);});
test('deleting a project removes its whole folder; busy or missing projects are refused',async t=>{
 const store=new JobStore(path.join(ROOT,'.cache','api-tests-'+randomUUID()));const pending=new Set();const queue={isBusy:id=>pending.has(id),enqueue(id){pending.add(id);},cancel(id){pending.delete(id);}};
 t.after(()=>fs.rmSync(store.root,{recursive:true,force:true}));
 const app=createApp({store,queue,youtube:new YouTubeClient({folder:path.join(store.root,'youtube-auth')})});const server=await new Promise(r=>{const s=app.listen(0,'127.0.0.1',()=>r(s));});t.after(()=>new Promise(r=>server.close(r)));const base=`http://127.0.0.1:${server.address().port}`;
 const job=store.create({type:'upload',filename:'stream.mp4'});const folder=store.folder(job.id);fs.mkdirSync(path.join(folder,'exports'));fs.writeFileSync(path.join(folder,'source.mp4'),'video');fs.writeFileSync(path.join(folder,'exports','a.mp4'),'clip');
 pending.add(job.id);let r=await fetch(base+'/api/jobs/'+job.id,{method:'DELETE'});assert.equal(r.status,409);assert.match((await r.json()).error,/Cancel processing/);assert.ok(fs.existsSync(folder));
 pending.delete(job.id);store.update(job.id,{status:'complete'});
 r=await fetch(base+'/api/jobs/'+job.id,{method:'DELETE',headers:{origin:'https://evil.test'}});assert.equal(r.status,403);assert.ok(fs.existsSync(folder),'foreign origins cannot delete');
 r=await fetch(base+'/api/jobs/'+job.id,{method:'DELETE'});assert.equal(r.status,200);
 assert.ok(!fs.existsSync(folder),'project folder is gone from disk');assert.deepEqual(fs.readdirSync(store.root).filter(f=>f.startsWith('.deleted-')),[],'no move-aside leftovers');
 r=await fetch(base+'/api/jobs');assert.equal((await r.json()).length,0);
 r=await fetch(base+'/api/jobs/'+job.id,{method:'DELETE'});assert.equal(r.status,404);
 fs.mkdirSync(path.join(store.root,'.deleted-x'));fs.writeFileSync(path.join(store.root,'.deleted-x','left.mp4'),'x');new JobStore(store.root);assert.ok(!fs.existsSync(path.join(store.root,'.deleted-x')),'leftovers are purged on start');
});
test('posts added before clip links are re-linked by identical export size, else by a unique clip title',()=>{
 const root=path.join(ROOT,'.cache','test-link-'+randomUUID()),folder=path.join(root,'job','exports');fs.mkdirSync(folder,{recursive:true});
 fs.writeFileSync(path.join(folder,'a.mp4'),'12345');fs.writeFileSync(path.join(folder,'b.mp4'),'1234567');
 const job={id:'job',title:'Stream',clips:[{id:'a',title:'Kai Wins'},{id:'b',title:'Kai Loses'}],exports:[{clipId:'a',filename:'a.mp4'},{clipId:'b',filename:'b.mp4'}]};
 const store={list:()=>[job],folder:id=>path.join(root,id)},linked={};
 const posting={list:()=>[{id:'p1',label:'Old label',media:{size:5}},{id:'p2',label:'Kai Loses',media:{size:99}},{id:'p3',label:'Nothing',media:{size:1}},{id:'p4',source:{jobId:'x',clipId:'y'},media:{size:5}}],link:(id,s)=>{linked[id]=s;}};
 try{linkOldPosts(store,posting);
  assert.equal(linked.p1.clipId,'a');assert.ok(linked.p1.videoMtime>0,'a size match is the same video');
  assert.equal(linked.p2.clipId,'b');assert.equal(linked.p2.videoMtime,0,'a title match offers the newer export');
  assert.ok(!linked.p3&&!linked.p4,'unmatched and already-linked posts are left alone');
 }finally{fs.rmSync(root,{recursive:true,force:true});}
});
test('adding a clip to the calendar twice updates the one draft, and a posted clip is skipped',async t=>{
 const {execFileSync}=await import('node:child_process');
 const store=new JobStore(path.join(ROOT,'.cache','api-tests-'+randomUUID()));const queue={isBusy:()=>false,enqueue(){},cancel(){}};
 const app=createApp({store,queue,youtube:new YouTubeClient({folder:path.join(store.root,'youtube-auth')})});const server=await new Promise(r=>{const s=app.listen(0,'127.0.0.1',()=>r(s));});t.after(()=>new Promise(r=>server.close(r)));t.after(()=>fs.rmSync(store.root,{recursive:true,force:true}));const base=`http://127.0.0.1:${server.address().port}`;
 const job=store.create({source:{type:'upload'},options:{}}),clipId=randomUUID(),file=path.join(store.folder(job.id),'exports',clipId+'.mp4');fs.mkdirSync(path.dirname(file),{recursive:true});
 const make=()=>execFileSync('ffmpeg',['-v','error','-y','-f','lavfi','-i','color=c=black:s=1080x1920:d=1:r=30','-f','lavfi','-i','anullsrc=r=48000:cl=stereo','-t','1','-c:v','libx264','-c:a','aac','-shortest',file]);make();
 store.update(job.id,{status:'complete',metadata:{duration:100},clips:[{id:clipId,start:0,end:30,title:'Kai Wins',settings:{},dirty:false,kept:true}],exports:[{clipId,filename:clipId+'.mp4'}]});
 const add=()=>fetch(base+'/api/posting/export',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jobId:job.id,clipId,format:'shorts',settings:{privacy:'private',madeForKids:false}})});
 let r=await add();assert.equal(r.status,201);const first=await r.json();
 r=await add();assert.equal(r.status,200);let again=await r.json();assert.equal(again.id,first.id);assert.equal(again.existing,'same');
 const later=new Date(Date.now()+5000);fs.utimesSync(file,later,later);r=await add();again=await r.json();assert.equal(again.id,first.id);assert.equal(again.existing,'updated','a re-export swaps the video into the same draft');
 const post=path.join(store.root,'posting',first.id,'post.json'),saved=JSON.parse(fs.readFileSync(post,'utf8'));fs.writeFileSync(post,JSON.stringify({...saved,videoId:'v',url:'https://youtu.be/v',state:'uploaded-private'}));
 r=await add();again=await r.json();assert.equal(again.existing,'posted');assert.equal(fs.readdirSync(path.join(store.root,'posting')).filter(n=>/^[a-f0-9-]{36}$/.test(n)).length,1,'still one post');
});
test('exports, sources and transcripts are served when the app lives under a dot-folder',async t=>{
 const store=new JobStore(path.join(ROOT,'.cache','api-tests-'+randomUUID(),'.hidden-root'));const queue={isBusy:()=>false,enqueue(){},cancel(){}};
 const app=createApp({store,queue,youtube:new YouTubeClient({folder:path.join(store.root,'youtube-auth')})});const server=await new Promise(r=>{const s=app.listen(0,'127.0.0.1',()=>r(s));});t.after(()=>new Promise(r=>server.close(r)));const base=`http://127.0.0.1:${server.address().port}`;
 const job=store.create({type:'upload'},{}),folder=store.folder(job.id),clipId=randomUUID();fs.mkdirSync(path.join(folder,'exports'),{recursive:true});
 fs.writeFileSync(path.join(folder,'exports',`${clipId}.mp4`),'video');fs.writeFileSync(path.join(folder,'transcript.json'),'{"words":[]}');fs.writeFileSync(path.join(folder,'source.mp4'),'source');
 store.update(job.id,{sourcePath:path.join(folder,'source.mp4'),clips:[{id:clipId,title:'Clip',start:0,end:30,kept:true}],exports:[{clipId,filename:`${clipId}.mp4`}]});
 for(const [url,body] of [[`/api/jobs/${job.id}/export/${clipId}`,'video'],[`/api/jobs/${job.id}/export/${clipId}?download=1`,'video'],[`/api/jobs/${job.id}/source`,'source'],[`/api/jobs/${job.id}/transcript`,'{"words":[]}']]){const r=await fetch(base+url);assert.equal(r.status,200,url);assert.equal(await r.text(),body);}
});
test('short meme clips can be edited; other templates still need 20 seconds',async t=>{
 const store=new JobStore(path.join(ROOT,'.cache','api-tests-'+randomUUID()));const queue={isBusy:()=>false,enqueue(){},cancel(){}};
 const app=createApp({store,queue,youtube:new YouTubeClient({folder:path.join(store.root,'youtube-auth')})});const server=await new Promise(r=>{const s=app.listen(0,'127.0.0.1',()=>r(s));});t.after(()=>new Promise(r=>server.close(r)));const base=`http://127.0.0.1:${server.address().port}`;
 const job=store.create({type:'upload'},{editTemplate:'skull-ending'}),clipId=randomUUID(),words=Array.from({length:40},(_,i)=>({text:'word',start:100+i*.3,end:100+i*.3+.25}));
 fs.mkdirSync(store.folder(job.id),{recursive:true});fs.writeFileSync(path.join(store.folder(job.id),'transcript.json'),JSON.stringify({words,duration:600}));
 store.update(job.id,{status:'complete',metadata:{duration:600,width:1920,height:1080},clips:[{id:clipId,title:'Old',start:100,end:113,kept:true,settings:{}}],exports:[]});
 const patch=body=>fetch(base+`/api/jobs/${job.id}/clips/${clipId}`,{method:'PATCH',headers:{'content-type':'application/json'},body:JSON.stringify(body)});
 let r=await patch({title:'New title'});assert.equal(r.status,200,await r.clone().text());
 r=await patch({settings:{editTemplate:'context-hit'}});assert.equal(r.status,400);assert.match((await r.json()).error,/at least 20 seconds/);
});
test('API creates Twitch and Kick jobs from their links and accepts live Twitch channels and refuses Kick channels with a clear reason',async t=>{
 const store=new JobStore(path.join(ROOT,'.cache','api-tests-'+randomUUID()));const queue={isBusy:()=>false,enqueue(){},cancel(){}};
 const app=createApp({store,queue,youtube:new YouTubeClient({folder:path.join(store.root,'youtube-auth')})});const server=await new Promise(r=>{const s=app.listen(0,'127.0.0.1',()=>r(s));});t.after(()=>new Promise(r=>server.close(r)));const base=`http://127.0.0.1:${server.address().port}`;
 const post=url=>fetch(base+'/api/jobs',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({url})});
 let r=await post('https://www.twitch.tv/kyle/v/2921164270');assert.equal(r.status,202);let job=await r.json();assert.deepEqual(job.source,{type:'twitch',kind:'video',name:'',url:'https://www.twitch.tv/videos/2921164270',section:null});
 r=await post('https://kick.com/xqc?clip=clip_01M73TDVGBGC62J5PMQZPPSG93');assert.equal(r.status,202);job=await r.json();assert.equal(job.source.type,'kick');assert.equal(job.source.kind,'clip');
 // A live Twitch channel imports the stream so far; Kick channels cannot (Kick shares only the last seconds while live).
 r=await post('https://www.twitch.tv/kyle');assert.equal(r.status,202);job=await r.json();assert.equal(job.source.kind,'channel');assert.equal(job.source.url,'https://www.twitch.tv/kyle');
 r=await post('https://kick.com/xqc');assert.equal(r.status,400);assert.match((await r.json()).error,/Kick channel.*last few seconds/);
});
